function _instantUpdateSettings() {
return {
	"baseLineGUID": "07b76cf70e0f41d89749676e8508e85f",
	"baseURL": "http://phonegapinstantupdate.s3.amazonaws.com/",
	"displayMessageAfterUpdate": false,
	"message": "",
	"systemMessages": "Verbose",
	"autoUpdate": true,
	"displayFirstTimeLoadMessage": true,
	"firstTimeRunMessage": ""
};
}